% Set dei parametri

clear all
clc
S_0=100; %10;
K=100;   %9;
r=0.01; %0.02;
T=1; %2;
sigma=0.04; %0.05;

%Discretizzazione
N=15;

%Calcolo con albero CRR
Call_E=european_option(S_0,sigma,r,K,T,N,1)
Put_E=european_option(S_0,sigma,r,K,T,N,-1)
Test_parity=Call_E-Put_E+K*(exp(-r*T))


%Calcolo analitico
[C_analitico,P_analitico]=blsprice(S_0,K,r,T,sigma)


%Calcolo con albero CRR
Call_A= american_option(S_0, sigma, r, K, T, N, 1)
Put_A = american_option(S_0, sigma, r, K, T, N, -1)
%Test_parity=Call_A-Put_A+K*(exp(-r*T))

if(Call_A-Put_A<=S_0-K*exp(-r*T))
    disp('Si giusto')
else
    disp('No')
end

%punto 3
N_1=3;
%Calcolo con albero CRR
Call_E_new=european_option(S_0,sigma,r,K,T,N_1,1)

%Calcolo con albero CRR
Call_A_new= american_option(S_0, sigma, r, K, T, N_1, 1)




