function P = american_option(S_0, sigma, r, K, T, N, flag)
% Prezzo di un'opzione americana (call o put) con il modello CRR
% flag = 1 (call), -1 (put)

if nargin == 6
    flag = 1; % default: call
end

if flag ~= 1 && flag ~= -1
    error('flag non è compatibile (usa 1 per call, -1 per put)');
end

% Parametri albero
delta = T / N;
u = exp(sigma * sqrt(delta));
d = 1 / u;  % corretto
rf = exp(r * delta);
p = (rf - d) / (u - d);
q = 1 - p;
discount = exp(-r * delta);

% Albero dei prezzi
%Si crea una matrice triangolare S di dimensione (N+1)x(N+1) dove ogni 
% colonna rappresenta un passo temporale, e ogni riga un livello dellpalbero:
S = zeros(N+1, N+1);
S(1,1) = S_0;
for j = 2:N+1
    S(1:j, j) = S_0 * u.^(j - (1:j)') .* d.^((1:j)' - 1);
end

% Payoff al tempo T
%Alla scadenza (colonna N+1), si calcola il valore intrinseco
% dell’opzione per ciascun nodo terminale
V = max(flag * (S(:, N+1) - K), 0);

% discesa all’indietro nell’albero)
% Per ogni passo j da N a 1 si aggiorna il valore dell'opzione nei nodi
for j = N:-1:1
    V = discount * (p * V(1:j) + q * V(2:j+1)); 
    %questo sopra calcola il valore atteso scontato dell'opzione nel nodo j, 
    % come combinazione lineare dei due valori futuri
    exercise = max(flag * (S(1:j, j) - K), 0);
    V = max(V, exercise);
    %per ogni nodo, si verifica se conviene esercitare subito
    %si confronta il valore ottenuto dalla continuazione con il valore di esercizio
end

P = V(1);  %prezzo dell'opzione
end
